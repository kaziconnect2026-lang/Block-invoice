# Block Invoice

Phase 1 + billing starter for an Invoice Ninja-inspired invoicing SaaS.

## Local setup

### Backend
```bash
cd backend
cp .env.example .env
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run dev
```

### Frontend
```bash
cd frontend
cp .env.example .env.local
npm install
npm run dev
```

## Deployment
- Deploy `frontend` to Vercel.
- Deploy `backend` to Railway.
- Add a Railway PostgreSQL database and set `DATABASE_URL`.
- Set `FRONTEND_URL` to the Vercel URL.
- Set Stripe keys and price IDs for Pro ($9/month) and Corporate ($13/month).
- Configure Stripe webhook endpoint: `https://YOUR-RAILWAY-DOMAIN/billing/webhook`.

## Notes
This is an MVP starter. Before public launch, add email verification, password reset, rate limiting, stronger validation, production logging, backups, and full billing lifecycle webhook handling.
