# Block Invoice

Phase 1 invoicing SaaS MVP.

## Structure
- `frontend`: Next.js app for Vercel
- `backend`: Express API for Railway

## Local setup
1. Create PostgreSQL database.
2. Copy `backend/.env.example` to `backend/.env`.
3. Copy `frontend/.env.example` to `frontend/.env.local`.
4. Run backend and frontend commands below.

### Backend
```bash
cd backend
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run dev
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```

Backend defaults to `http://localhost:4000`.
