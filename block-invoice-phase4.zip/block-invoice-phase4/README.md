# Block Invoice — Phase 4

Production-readiness starter for a simple invoicing SaaS.

## Stack
- Next.js frontend for Vercel
- Express + TypeScript API for Railway
- PostgreSQL + Prisma
- JWT authentication
- PDF invoices with PDFKit
- Stripe checkout/webhook starter

## Run locally

### Backend
```bash
cd backend
npm install
cp .env.example .env
npx prisma generate
npx prisma migrate dev --name init
npm run dev
```

### Frontend
```bash
cd frontend
npm install
cp .env.example .env.local
npm run dev
```

## Deployment

1. Create a Railway PostgreSQL service.
2. Deploy `backend` as a Railway service.
3. Set backend environment variables from `.env.example`.
4. Set the Railway start command to `npm run start` and build command to `npm run build`.
5. Deploy `frontend` to Vercel.
6. Set `NEXT_PUBLIC_API_URL` to the Railway API URL.
7. Configure Stripe webhook endpoint as:
   `https://YOUR-RAILWAY-DOMAIN/billing/webhook`
8. Use Stripe test keys first.

## Before accepting real payments

- Add subscription renewal, cancellation, failed-payment, and customer-portal handling.
- Add email verification and password reset flows.
- Add rate limiting and stronger request validation.
- Add database migrations and backups.
- Test tenant isolation and invoice numbering under concurrency.
- Configure HTTPS, monitoring, and secret management.

This is not a substitute for a security review.
