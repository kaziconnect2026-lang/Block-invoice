# Block Invoice — Phase 3

Next.js frontend + Express TypeScript API + PostgreSQL/Prisma.

## Added in Phase 3
- Billing tab with Pro $9/month and Corporate $13/month checkout buttons.
- Client creation UI.
- Invoice dashboard and PDF links.
- Stripe checkout uses backend `/billing/checkout`.

## Run locally

Backend:
```bash
cd backend
npm install
cp .env.example .env
npx prisma generate
npx prisma migrate deploy
npm run dev
```

Frontend:
```bash
cd frontend
npm install
cp .env.example .env.local
npm run dev
```

Set `NEXT_PUBLIC_API_URL` to the Railway API URL. Set Stripe price IDs and webhook secret in Railway. Configure Stripe webhook endpoint:
`https://YOUR-RAILWAY-DOMAIN/billing/webhook`

## Deployment
- Deploy `frontend` as a Vercel project.
- Deploy `backend` as a Railway service.
- Add Railway PostgreSQL and set `DATABASE_URL`.
- Set `FRONTEND_URL` to the Vercel URL.
- Set `STRIPE_SECRET_KEY`, `STRIPE_PRO_PRICE_ID`, `STRIPE_CORPORATE_PRICE_ID`, and `STRIPE_WEBHOOK_SECRET`.

This is an MVP starter. Complete production security review, subscription lifecycle events, email delivery, and end-to-end tests before accepting real customer payments.
